<?php

//class
class Test {

}

//object
$a = new Test();
$b = new Test();
$c = new Test();

echo var_dump($a);
echo var_dump($b);
echo var_dump($c);


?>